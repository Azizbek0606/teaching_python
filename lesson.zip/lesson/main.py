# name = "azizbek"
# print(f"salom {name}")
# numbers = [1, 2, 3, 4, 5 , "txt" , {"key":"value"}, 1.45]

# for u in range(0 , len(numbers) ,2):
#     print(numbers[u])

# a = 100

# while a > 0:
#     print(True)
#     a -= 1

# a = 'azizbek'
# print(a[2])
# a = [1,2,3]
# a.pop(1)
# a.remove(1)
# b = a.copy()
# print(a)
# print(b)
# for i in range(5):
#     a.append(i)
# print(a)


# person = {"name": "John", "age": 25, "city": "New York"}
# unique_numbers = {1, 2, 3, 4, 5}
# frozen_numbers = frozenset([1, 2, 3, 4, 5])
# print(frozen_numbers)
# byte_data = b"Hello"
# print(byte_data)

# x = {
#     "key": "value1",
#     "key2": "value2",
#     "key3": "value3"
# }
# for x , y in x.items():
#     print(f"{y}")
# x.update({"key5": "value1", "key7": "value1"})
# x.setdefault("key1", "value666")
# x.setdefault("key", "value7")
# print(x)
# a = x.popitem()
# print(x)
# print(a)

# def func(x,u , default_value=17):
#     return x + u + default_value

# print(func(10, 20))

# def for_args(*args):
#     print(type(args))
#     for x in args:
#         print(x)

# for_args(1, 2, 3, 4, 5 , "sxssdad" , {"asa":'sas'})

# def test_kw(x):
#     print(type(x))

#     for key, value in x.items():
#         print(f"{key} = {value}")

# x = {
#     1: "John",
#     2: "Alice",
#     3: "Bob"
# }

# test_kw(x)

# a = lambda x , y: x * x * y

# print(a(5 , 7))

# a = [x for x in range(10) if x % 2 == 0]
# print(a)

# b = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# for i in b:
#     if i % 2 == 0:
#         print(i)

# m = True
# print("shu javob to'g'ri" if m == True else "boshqa javob chiqadi")